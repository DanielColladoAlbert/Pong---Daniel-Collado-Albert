import turtle

wn = turtle.Screen()
wn.title("Pong 1 DAW")
wn.bgcolor("black")
wn.setup(width=800, height=600)
wn.tracer(0)

scoreA = 0
scoreB = 0

playerA = turtle.Turtle()
playerA.speed(0)
playerA.shape("square")
playerA.color("white")
playerA.penup()
playerA.goto(-350,0)
playerA.shapesize(stretch_wid=5, stretch_len=1)

playerB = turtle.Turtle()
playerB.speed(0)
playerB.shape("square")
playerB.color("white")
playerB.penup()
playerB.goto(350,0)
playerB.shapesize(stretch_wid=5, stretch_len=1)

ball = turtle.Turtle()
ball.speed(0)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0,0)

ball.dx = 0.2
ball.dy = 0.2

pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0,260)
pen.write("Player A: 0     Player B:  0", align="center", font=("Courier", 25, "normal"))

def playerA_up():
    y = playerA.ycor()
    y += 20
    playerA.sety(y)

def playerA_down():
    y = playerA.ycor()
    y -= 20
    playerA.sety(y)

def playerB_up():
    y = playerB.ycor()
    y += 20
    playerB.sety(y)

def playerB_down():
    y = playerB.ycor()
    y -= 20
    playerB.sety(y)

wn.listen()
wn.onkeypress(playerA_up, "w")
wn.onkeypress(playerA_down, "s")
wn.onkeypress(playerB_up, "Up")
wn.onkeypress(playerB_down, "Down")

while True:
    wn.update()

    ball.sety(ball.ycor() + ball.dy)
    ball.setx(ball.xcor() + ball.dx)
    
    if ball.ycor() > 290:
        ball.dy *= -1
    if ball.ycor() < -290:
        ball.dy *= -1
    
    if ball.xcor() > 390:
        ball.goto(0,0)
        ball.dx *= -1
        scoreA += 1
        pen.clear()

        pen.write(f"Player A: {scoreA}            Player B: {scoreB}", align="center", font=("Courier",25, "normal"))

    if ball.xcor() < -390:
        ball.goto(0,0)
        ball.dx *= -1
        scoreA += 1
        pen.clear()

        pen.write(f"Player A:   {scoreA}            Player B: {scoreB}", align="center", font=("Courier",25, "normal"))

    if ((ball.xcor() > 340 and ball.xcor() < 350) and (ball.ycor() < playerB.ycor() + 50 and ball.ycor() > playerB.ycor() - 50)):
        ball.dx *= -1
    if ((ball.xcor() < -340 and ball.xcor() > -350) and (ball.ycor() < playerA.ycor() + 50 and ball.ycor() > playerA.ycor() - 50)):
        ball.dx *= -1